CREATE DATABASE sqlidojo;

CREATE USER sa FOR LOGIN sa;
ALTER ROLE db_owner ADD MEMBER sa;
USE master;
ALTER AUTHORIZATION ON DATABASE::sqlidojo TO sa;

USE sqlidojo;

-- Create PEOPLE table
CREATE TABLE PEOPLE (
    id INT IDENTITY(1,1) PRIMARY KEY, -- Use IDENTITY for auto-increment
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    email VARCHAR(100) NOT NULL
);

-- Insert records into PEOPLE table
INSERT INTO PEOPLE (first_name, last_name, email) VALUES
    ('Sofia', 'Ivanova', 'sofia.ivanova@example.com'),
    ('Alejandro', 'Santos', 'alejandro.santos@example.com'),
    ('Li', 'Wei', 'li.wei@example.com'),
    ('Isabella', 'Rossi', 'isabella.rossi@example.com'),
    ('Hassan', 'Al-Mansoori', 'hassan.al-mansoori@example.com'),
    ('Lars', 'Andersen', 'lars.andersen@example.com'),
    ('Fatima', 'Khan', 'fatima.khan@example.com'),
    ('Andre', 'Silva', 'andre.silva@example.com'),
    ('Aisha', 'Patel', 'aisha.patel@example.com'),
    ('Hugo', 'Dubois', 'hugo.dubois@example.com'),
    ('Mia', 'Jansson', 'mia.jansson@example.com'),
    ('Amir', 'Hamidi', 'amir.hamidi@example.com'),
    ('Natalia', 'Petrovich', 'natalia.petrovich@example.com'),
    ('Diego', 'Ramirez', 'diego.ramirez@example.com'),
    ('Katarina', 'Sokolov', 'katarina.sokolov@example.com'),
    ('Javier', 'Morales', 'javier.morales@example.com'),
    ('Leila', 'Rahman', 'leila.rahman@example.com'),
    ('Viktoriya', 'Yermakov', 'viktoriya.yermakov@example.com'),
    ('Lucas', 'Costa', 'lucas.costa@example.com'),
    ('Yuki', 'Tanaka', 'yuki.tanaka@example.com');

-- Create FILTER_SETUP table
CREATE TABLE FILTER_SETUP (
    ID INT IDENTITY(1,1) PRIMARY KEY, -- Use IDENTITY for auto-increment
    FILTER_CHARACTER VARCHAR(1) NOT NULL
);

-- Create FILTER_PHRASE_SETUP table
CREATE TABLE FILTER_PHRASE_SETUP (
    ID INT IDENTITY(1,1) PRIMARY KEY, -- Use IDENTITY for auto-increment
    FILTER_PHRASE VARCHAR(100) NOT NULL
);

-- Create SECRET_TABLE
CREATE TABLE SECRET_TABLE (
    id INT IDENTITY(1,1) PRIMARY KEY, -- Use IDENTITY for auto-increment
    SECRET_VALUE VARCHAR(50) NOT NULL
);

-- Insert record into SECRET_TABLE
INSERT INTO SECRET_TABLE (SECRET_VALUE) VALUES ('SQL Injection Dojo');
