#!/bin/bash

# Update and install system dependencies
apt-get update && apt-get install -y \
    gnupg \
    unixodbc \
    unixodbc-dev \
    curl \
    apt-transport-https \
    build-essential

# Add Microsoft repository for ODBC drivers
curl https://packages.microsoft.com/keys/microsoft.asc | apt-key add -
curl https://packages.microsoft.com/config/debian/11/prod.list > /etc/apt/sources.list.d/mssql-release.list

# Install ODBC drivers
apt-get update
ACCEPT_EULA=Y apt-get install -y mssql-tools18

# Add mssql-tools to PATH
echo 'export PATH="$PATH:/opt/mssql-tools18/bin"' >> ~/.bashrc
source ~/.bashrc
echo "[ODBC Driver 18 for SQL Server]" >> /etc/odbcinst.ini
echo "Description=Microsoft ODBC Driver 18 for SQL Server" >> /etc/odbcinst.ini
echo "Driver=/opt/microsoft/msodbcsql18/lib64/libmsodbcsql-18.4.so.1.1" >> /etc/odbcinst.ini
export LD_LIBRARY_PATH=/opt/microsoft/msodbcsql18/lib64:$LD_LIBRARY_PATH
echo "LD_LIBRARY_PATH=/opt/microsoft/msodbcsql18/lib64:$LD_LIBRARY_PATH" >> /etc/environment
source /etc/environment
# Install PHP extensions for SQL Server
pecl install pdo_sqlsrv sqlsrv
docker-php-ext-enable pdo_sqlsrv sqlsrv

# Optional: Clean up to reduce container size
apt-get clean && rm -rf /var/lib/apt/lists/*

# Run your PHP script to initialize the application
php /var/init-scripts/init.php

# Start PHP-FPM
exec php-fpm

