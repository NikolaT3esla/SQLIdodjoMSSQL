<?php
$dsn = 'sqlsrv:Server=mssql,1433;Database=sqlidojo';
$username = 'sa';
$password = 'YourStrong@Passw0rd';

try {
    $pdo = new PDO($dsn, $username, $password);
    echo "Connection successful!";
} catch (PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
}

