<?php
$serverName = "mssql,1433"; // "mssql" is the service name in Docker Compose
$connectionOptions = [
    "Database" => "sqlidojo",
    "Uid" => "sa",
    "PWD" => "YourStrong@Passw0rd",
    "TrustServerCertificate" => true // Add this to bypass SSL validation
];

try {
    $conn = sqlsrv_connect($serverName, $connectionOptions);

    if ($conn) {
        echo "Connection successful!";
    } else {
        echo "Connection failed: ";
        print_r(sqlsrv_errors());
    }
} catch (Exception $e) {
    echo "Exception: " . $e->getMessage();
}
